package com.courseservice.entity;

public class course {

}
