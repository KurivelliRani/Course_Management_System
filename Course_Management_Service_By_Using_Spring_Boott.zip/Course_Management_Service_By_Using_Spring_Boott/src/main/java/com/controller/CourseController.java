package com.controller;

public class CourseController {
	@Autowired
	private CourseService courservice;
	@GetMapping
	public List<Course>getAllCourse(){
		return courseService.getAllCourse();
	}
@GetMapping("/id")
public Course getCourseById(@PathVariable int id) {
	return courseService.getCourseById(id);
	
}
@GetMapping("/multiple")
public List<Course>getCourseByIds){
	return courseService.getCourseById(ids)
}
}
