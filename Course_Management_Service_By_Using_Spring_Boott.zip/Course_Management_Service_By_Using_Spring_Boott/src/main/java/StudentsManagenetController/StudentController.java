package StudentsManagenetController;

import StudentsManagenetController.Autowired;
import StudentsManagenetController.GetMapping;
import StudentsManagenetController.List;
import StudentsManagenetController.PathVariable;
import StudentsManagenetController.Student;

public class StudentController {
	@Autowired
	private Student Service studentservice;
	
	@GetMapping
	public List<Student>getAllStudents(){
		return studentService.getAllStudenrs();
	}
	
	@GetMapping
	public Student getStudentById(@PathVariable int id) {
		return studentService.getStudentById(id);
	}


}
