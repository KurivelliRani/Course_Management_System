package courseservice.repository;

import courseservice.repository.Couse;
import courseservice.repository.jparepository;

public interface CourseRepository extends jparepository<Couse,Integer>{}


