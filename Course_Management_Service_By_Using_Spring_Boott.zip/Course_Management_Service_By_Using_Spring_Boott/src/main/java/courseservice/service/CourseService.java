package courseservice.service;
public class CourseService{
	private List<course>courses=new ArrayList<>();
	public CourseService() {
		courses.add(new Course(1,"java","corejava","javascripe"));
		courses.add(new Course(2,"springboot","building rest api","spring web mvc"));
		courses.add(new Course(3,"mysql","Databasefundamentals","css"));
		
		public List<Course>getAllCouses(){
			return course;
		}
		public Course getCouseById(int id) {
			return courses.stream().filter(c.getId()==id.findFirst().orElse(null);
			
		}
		public List<Course>
		getCoursesByIds(List<Integr>ids){
			return return courses.stream().filter(c.getId()==id.findFirst().orElse(null)
		}
		
		
		
	}
	
}

